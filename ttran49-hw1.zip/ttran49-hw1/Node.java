public class Node<T> {
  protected static final int NULL = -1;
  protected int previous;
  protected int next;
  protected T data;
 
  // Constructor initializes data members. See method init().
  protected Node(){
	  init();
  }
 
  // Create a pretty representation of the pool
  // Format: [previous,next,data]
  // Target Complexity: O(n)
  public String toString(){
	  return "[" +previous+ ", " +next+ ", " +data+ "]";
  }
 
  // Initializes the data members. 
  // Called by the constructor and also by method reset() 
  // in class NodePool.
  // Target Complexity: O(1)
  protected void init(){
	  next=NULL;
	  previous=NULL;
	  data=null;
  }
} 