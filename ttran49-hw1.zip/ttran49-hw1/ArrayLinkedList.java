/**
 *  everytime remove a node, that node position become firstEmpty;
 *  number++;
 *	 
 */
import java.util.*;
class ArrayLinkedList<T> {
	protected final static int NODEPOOLSIZE = 8;
    protected final static int NULL = -1;      
	protected ArrayList<Node<T>> array = new ArrayList<>() ;
	protected NodePool<T> pool= new NodePool<>(NODEPOOLSIZE);
    protected int head; // position of dummy node in array
    protected int tail; // position of tail node in array
    protected int firstEmpty; // head of the list of empty nodes
    protected int numberEmpty; // number of empty nodes
	protected int size = 0; // number of non-empty nodes
    protected int modCount; // number of modifications made

 
    // Constructor to initialize the data members, increment modCount,
    // create the dummy header Node, and add it to array
    public ArrayLinkedList(){
		Node dummy= pool.allocate();
		array.add(dummy);
		head=0;
		tail=0;
		firstEmpty = dummy.previous;
		modCount++;
	}
 
    // Return number of non-empty nodes
    // Target Complexity: O(1)
    public int size(){
		return size;
	}
 
    // convenience methods for debugging and testing
	// check position is empty
	//return -1 if non found
    protected int getFirstEmpty(){
		int empty = -1;
		for (int i =0; i <array.size();i++){
			if (positionIsEmpty(i)){
				empty=i;
				break;
			}
		}
		return empty;
	}// return firstEmpty
    protected int getHead(){
		return head;
	} // return head
    protected int getTail(){
		return tail;
	} // return tail
    protected ArrayList<Node<T>> getArray(){
		return array;
	} // return array
     
	 
    /*
	* 	Appends the specified element to the end of this list. 
	*	Returns true.
	*	If no empty Nodes are available, then get a new Node from pool.
	*	Throws IllegalArgumentException if e is null.
	*	Checks assertions at the start and end of its execution.
	*	Target Complexity: Amortized O(1)
	*/
    public boolean add(T e) {
        assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0  
         && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL)
          && (array.size() == size+numberEmpty+1);   
		
		boolean success= false;
        //check for null e
		if (e == null)
			throw new IllegalArgumentException();
		//check if arraylist is empty
		if (array.size()== 1){
			//adding
			Node p = pool.allocate();
			p.data= e;
			array.add(p);
			//update data fields
			p.previous = 0;
			size++;
			array.get(head).next=size();
			tail= array.indexOf(p);
			success=true;
		}else{
			//find last empty node in array to replace
			int empty = -1;
			for (int i =0; i < array.size();i++){
				if (positionIsEmpty(i)){
					empty=i;
				}
			}
			
			//add if non empty node found
			if (empty == -1){
				//add
				Node temp = pool.allocate();
				temp.data=e;
				array.add(temp);
				//update stuff
				temp.previous= tail;
				array.get(tail).next= array.indexOf(temp);
				tail= array.indexOf(temp);
				success=true;
				size++;
				
			//found empty node
			}else{
				//replace empty node
				array.get(tail).next=empty;
				array.get(empty).data=e;
				array.get(empty).previous= tail;
				array.get(empty).next=-1;
				tail= empty;
				success=true;
				size++;
				numberEmpty--;
				firstEmpty=getFirstEmpty();
			}
		}
		
        // check this assertion before each return statement
        assert size>0 && head==0 && numberEmpty >=0 
			&& (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
				&& firstEmpty!=NULL)
				&& (array.size() == size+numberEmpty+1);
			return success;
	}

 
    // Inserts the specified element at the specified index in this list.  
    // Shifts the element currently at that index (if any) and any 
    // subsequent elements to the right (adds one to their indices).    
    // Throws IndexOutOfBoundsException if the index is out of range 
    // (index < 0 || index > size()).
    // Throws IllegalArgumentException if e is null.
    // Can call add(T e) if index equals size, i.e., add at the end
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public void add(int index, T e) {
       assert size>=0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
           && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
 
		if (index < 0 || index > size())
			throw new IndexOutOfBoundsException();
		if (e == null)
			throw new IllegalArgumentException();
		//adding
		if (index == size()){
			add(e);
		}else{
			Node p = pool.allocate();
			p.data= e;
			array.add(p);
			Node temp = new Node();
			temp = array.get(head);
			//go to index
			int ctr=0;
			while (ctr <= index){
				temp=array.get(temp.next);
				//found index, add
				if (ctr==index){
					p.next= array.indexOf(temp);
					p.previous= temp.previous;
					temp.previous= array.indexOf(p);
					array.get(p.previous).next=array.indexOf(p);

				}
				ctr++;
			}
			size++;
		}
 
       // check this assertion before each return statement
       assert size>0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
             && firstEmpty!=NULL) && (array.size() == 
                 size+numberEmpty+1);
       return;
	
    }
 
    // Equivalent to add(0,e).
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(1)
    public void addFirst(T e){
		add(0,e);
	}
 
    // Equivalent to add(e).
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(1)
    public void addLast(T e){
		add(e);
	}
 
    // Add all of the elements (if any) in Collection c to the end 
    // of the list, one-by-one.
    // Returns true if this list changed as a result of the call.
    // Throws NullPointerException if the specified collection is null
    // Target Complexity: O(number of elements in c)
    public boolean addAll(Collection<? extends T> c){
		if(c==null)
			throw new NullPointerException();
		int temp = size();
		for(T e :c){
			add(e);
		}
		if(temp!= size())
			return true;
		return false;
	}
 
    // Returns true if this list contains the specified element.
    // Throws IllegalArgumentException if e is null
    // May call indexOf(e)
    // Target Complexity: O(n)
    public boolean contains(T e){
		if (e == null)
			throw new IllegalArgumentException();
		Node temp=new Node();
		temp= array.get(head);
		//loop through linked list to find e
		while(temp.next != -1){
			temp=array.get(temp.next);
			if (e.equals(temp.data))
				return true;
		}
		return false;
	}
 
 
    // Returns the index of the first occurrence of the 
    // specified element in this list,
    // or NULL if this list does not contain the element.
    // Throws IllegalArgumentException if e is null
    // Target Complexity: O(n)
    public int indexOf(T e){
		if (e == null)
			throw new IllegalArgumentException();
		
		//if contain => find
		if (contains(e)){
			int index=0;
			Node p= new Node();
			p= array.get(head);
			
			//loop through to find
			while(p.next != -1){
				p=array.get(p.next);
				if (e.equals(p.data)){
					return index;
				}
				index++;
			}
		}
		return -1;
	}
    
   // Returns the array position of the first occurrence of 
   // the specified element in array
   // or NULL (-1) if this list does not contain the element. 
   // Note that the return value is a position in the array, 
   // not the index of an element in the list.
   // Called by remove(T e) to find the position of e in the array.
   // Throws IllegalArgumentException if e is null
   // Target Complexity: O(n)
   protected int positionOf(T e){
	   if (e == null)
			throw new IllegalArgumentException();
		//check containment 
		if (contains(e)){
			Node temp=new Node();
			temp=array.get(head);
			//loop through to find
			while(temp.next!=-1){
				temp=array.get(temp.next);
				if(e.equals(temp.data))
					return array.indexOf(temp);
			}
		}
		return -1;
    }
 
    // Returns the element at the specified index in this list.
    // Throws IndexOutOfBoundsException if the index is out 
    // of range (index < 0 || index >= size())
    // Target Complexity: O(n)
    public T get(int index){
		if (index < 0 || index >= size())
			throw new IndexOutOfBoundsException();
		Node temp = new Node();
		temp= array.get(array.get(head).next);
		//loop to index, return
		for (int i =0; i<= index;i++){
			if (i == index){
				return (T) temp.data;
			}
			temp= array.get(temp.next);
		}	
		return null;
	}
 
    // Returns the first element in the list.
    // Throws NoSuchElementException if the list is empty
    // Target Complexity: O(1)
    public T getFirst(){
		if(size()==0)
			throw new NoSuchElementException();
		return array.get(array.get(head).next).data;
	}
 
    // Returns the last element in the list
    // Throws NoSuchElementException if the list is empty
    // Target Complexity: O(1)
    public T getLast(){
		if(size()==0)
			throw new NoSuchElementException();
		return array.get(tail).data;
	}
 
    // Remove the node at position current in the array.
    // Note that current is a position in the array, not the 
    // index of an element in the list.
    // The removed node is made empty and added to the front 
    // of the list of empty Nodes. Dummy node cannot be removed.
    // Called by remove(T e) and remove(int index) to 
    // remove the target Node.
    // Target Complexity: O(1)
    protected void removeNode(int current) {
       assert current > 0 && current < array.size();
		if (current == 0)
			return;
		//update previous, next of neighbor
		//release
		//update firempty for empty nodes data fields
		if (current == tail){
			tail = array.get(current).previous;
			array.get(tail).next=-1;
			pool.release(array.get(current));
			array.get(current).next=firstEmpty;
		} else{	
			array.get(array.get(current).previous).next =array.get(current).next;
			array.get(array.get(current).next).previous= array.get(current).previous;
			pool.release(array.get(current));
			
		}
		firstEmpty=current;
    }
 
    // Removes the first occurrence of the specified element from 
    // this list, if it is present. Returns true if this
    // list contained the specified element.
    // Throws IllegalArgumentException if e is null.
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public boolean remove(T e) {
 
       assert size>=0 && head==0 && numberEmpty >=0
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
		if (e == null)
		   throw new IllegalArgumentException();
	   //if contain, call removenode
		if(contains(e)){
			removeNode(positionOf(e));
			size--;
			numberEmpty++;
		}
 
       // check this assertion before each return statement
       assert size>=0 && head==0 && numberEmpty >=0 
         && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);
       return (!contains(e));
    }
 
    // Removes the element at the specified index in this list.
    // Shifts any subsequent elements to the left (subtracts one from
    // their indices). Returns the element that was removed from the 
    // list. Throws IndexOutOfBoundsException if the index is 
    // out of range (index < 0 || index >= size)
    // Checks assertions at the start and end of its execution.
    // Target Complexity: O(n)
    public T remove(int index) {
      assert size>=0 && head==0 && numberEmpty >=0 
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
          && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);

		if (index < 0 || index >= size)
			throw new IndexOutOfBoundsException();

		Node temp= new Node();
		temp = array.get(head);
		T rmData=null;
		int ctr=0;
		//loop to index
		while(temp.next!=-1){
			temp=array.get(temp.next);
			//found index, call removenode
			if (ctr == index){
				rmData= (T)temp.data;
				removeNode(array.indexOf(temp));
			}
			ctr++;
		}
		size--;
		numberEmpty++;
		
 
        // check this assertion before each return statement
       assert size>=0 && head==0 && numberEmpty >=0 && (numberEmpty==0 
        && firstEmpty==NULL) || (numberEmpty>0 && firstEmpty!=NULL) 
        && (array.size() == size+numberEmpty+1);
		return rmData ;
    }
 
    // Returns the first element in the list.
    // Throws NoSuchElementException if the list is empty.
    // Equivalent to remove(0), for index 0
    // Target Complexity: O(1)
    public T removeFirst(){
		if (size()==0)
			throw new NoSuchElementException();
		return remove(0);
	}
 
    // Returns the last element in the list
    // Throws NoSuchElementException if the list is empty
    // Equivalent to remove(size-1), for index size-1
    // Target Complexity: O(1)
    public T removeLast(){
		if(size()==0)
			throw new NoSuchElementException();
		return remove(size() -1);
	}
 
    // Returns true if the Node at the specified position in the 
    // array is an empty node. The dummy node is never considered to be
    // an empty node.
    // Target Complexity: O(1)
    protected boolean positionIsEmpty(int position) {
      assert position > 0 && position < array.size();
		//return true if .data == null; position >= to array size
		if (position == 0)
			return false;
		if (position >= array.size())
			return true;
		else if (array.get(position).data == null){
			return true;
		}
		return false;
    }
 
    // Returns number of empty nodes.
    // Target Complexity: O(1)
    protected int numEmpty(){
		int count=-1;
		//loop through array, call positionIsEmpty on each position
		for (int i =0; i <= array.size(); i++){
			if (positionIsEmpty(i))
				count++;
		}
		return count;
	}
 
    // Replaces the element at the specified position in this 
    // list with the specified element. Returns the element 
    // previously at the specified position.    
    // Throws IllegalArgumentException if e is null.
    // Throws IndexOutOfBoundsException if index is out of 
    // range (index < 0 || index >= size)
    // Target Complexity: O(n)
    public T set(int index, T e){
		if (e == null)
			throw new IllegalArgumentException();
		if (index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		Node temp = new Node();
		temp = array.get(array.get(head).next);
		//loop through to index, update data to e
		for (int i =0; i<= index;i++){
			if (i == index){
				temp.data = e;
				return e;
			}
			temp=array.get(temp.next);
		}
		return null;
	}
 
    // Removes all of the elements from this list. 
    // The list will be empty after this call returns.
    // The array will only contain the dummy head node.
    // Some data members are reinitialized and all Nodes
    // are released to the node pool. modCount is incremented.
    // Target Complexity: O(n)
    public void clear() {
       assert size>=0 && head==0 && numberEmpty >=0 
        && (numberEmpty==0 && firstEmpty==NULL) || (numberEmpty>0 
        && firstEmpty!=NULL) && (array.size() == size+numberEmpty+1);

		//go through the list, release all nodes
		for (int i =0; i <= size();i++){
			if(i >= size()){
				removeLast();
				break;
			}
			remove(i);
		}		
		//remove all the node from array
		int temp= array.size()-1; 
		for (int i= temp; i >=1;i--){
			array.remove(i);
		}
		//reset stuffs
		tail=0;
		size=0;
		array.get(head).next=-1;
		numberEmpty= 0;
		firstEmpty= -1;

       // check this assertion before each return statement
       assert size==0 && head==0 && numberEmpty==0 && firstEmpty==NULL
       && (array.size() == size+numberEmpty+1);
       return;
    }
 
    // Returns an Iterator of the elements in this list, 
    // starting at the front of the list
    // Target Complexity: O(1)
    Iterator<T> iterator(){
		//create new iterator
		return new ArrayLinkedListIterator(); 
	}
 
    // Convenience debugging method to display the internal 
    // values of the list, including ArrayList array
    protected void dump() {
      System.out.println();
      System.out.println("**** dump start ****");
      System.out.println("size:" + size);
      System.out.println("number empty:" + numberEmpty);
      System.out.println("first empty:"+firstEmpty);
      System.out.println("head:" + head);
      System.out.println("tail:" + tail); 
      System.out.println("list:");
      System.out.println("array:");
      for (int i=0; i<array.size(); i++) // show all elements of array
         System.out.println(i + ": " + array.get(i));
      System.out.println("**** dump end ****");
      System.out.println();
    }
 
    // Returns a textual representation of the list, i.e., the 
    // data values of the non-empty nodes in list order.
    public String toString(){
		//return data of all nodes in string format- no space
		String output="";
		Node p=new Node();
		p= array.get(head);
		while(p.next!= -1){
			p=array.get(p.next);
			if (p.data != null)
				output = output+ p.data;
		}
		return output;
	}
 
    // Compress the array by releasing all of the empty nodes to the 
    // node pool.  A new array is created in which the order of the 
    // Nodes in the new array matches the order of the elements in the 
    // list. When compress completes, there are no empty nodes. Resets 
    // tail accordingly.
    // Target Complexity: O(n)
    public void compress(){
		ArrayList<Node<T>> temp=new ArrayList<>();		
		Node p= new Node();
		p= array.get(head);
		temp.add(p);
		
		//add non empty nodes to new array
		while(p.next!=-1){
			p=array.get(p.next);
			temp.add(p);
		}
		
		//update the pointers in new array
		temp.get(head).next=1;
		for (int i=1;i<temp.size();i++){
			temp.get(i).next = i+1;
			temp.get(i).previous=i-1;
		}
		//set stuff
		temp.get(temp.size()-1).next=-1;
		tail= temp.size()-1;
		array=temp;
		
	}
 
    // Iterator for ArrayLinkedList. (See the description below.)
    private class ArrayLinkedListIterator implements Iterator<T> {
		Node temp= new Node();
		int index=-1;
      // Constructor
      // Target Complexity: O(1)
      public ArrayLinkedListIterator (){
		  //start at head with index =-1
		  temp= array.get(head);
		  index=-1;
	  }
 
      // Returns true if the iterator can be moved to the next() element.
      public boolean hasNext(){
		if (temp.next==-1)
			return false;
		return true;
	  }
 
      // Move the iterator forward and return the passed-over element
      public T next(){
		//move index and return
		index++;
		temp= array.get(temp.next);
		return get(index);
	  }
	
 
      // The following operation is part of the Iterator interface 
      // but is not supported by the iterator. 
      // Throws an UnsupportedOperationException if invoked.
      public void remove(){
		  //not supported method
		throw new UnsupportedOperationException();
	  }
    }
}