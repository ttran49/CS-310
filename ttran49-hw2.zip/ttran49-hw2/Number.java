import java.util.*;
/**
 *  mulication is almost perfect, decimal point and why fucking lots of digits.
 *  print out everywhere
 */
public class Number{
	private Node low, high;
	private int digitCount = 0;
	private int decimalPlaces = 0;
	private boolean negative = false;
	
	/*
		Constructor
	*/
	public Number(){

	}
	
	/*
		Constructor with String
		A constructor which takes a String representation of a number (e.g. "-21.507"). Calls accept.
	*/
	public Number(String str){
		try {accept(str);}
		catch (Exception e){
			System.out.println("BAD NUMBER!");
		}
		
	}
	/*
		accept, Builds a list representation of the number represented by the string. 
	*/
	public void accept(String str)throws BadNumberException{
		try {
			validate(str);
		}
		catch (Exception e){
			throw new BadNumberException();
		}
		int i=0;
		
		//check negative
		if (Character.compare('-', str.charAt(0))==0){
			i++;
			negative=true;
		}
		//check leading zeroes
		while(Character.compare('0', str.charAt(i))==0 && str.length()>1)
			i++;
		//check for . in the beginning
		if (Character.compare('.', str.charAt(0))==0){
			i++;
			decimalPlaces= str.length()- (i+1);
		}
		//setting up the first Node
		Node temp= new Node(Character.digit(str.charAt(i),10));
		i++;
		digitCount++;
		high = temp;
		low=temp;

		//gettting the rest of the number in the linkedlisit
		while (i< str.length()){
			if (Character.compare('.',str.charAt(i))==0){
				decimalPlaces= str.length()- (i+1);
			} else {
				Node num= new Node(Character.digit(str.charAt(i),10));
				num.previous= low;
				low.next=num;
				low= num;
				digitCount++;
			}
			i++;
		}
	}
	/*
		called by vaidate to check number
	*/
	private boolean checkNum(String number){
		int i =0;
		if (Character.compare(number.charAt(0), '-')==0 || Character.compare(number.charAt(0), '.')==0){
			i=1;
		}
		boolean twice=false;
		while (i < number.length()){
			if (Character.compare('.', number.charAt(i))==0){
				if (twice)
					return false;
				else
					twice=true;
			}else {
				if (!Character.isDigit(number.charAt(i)))
					return false;
			}
			i++;
		}
		return true;
	}
	
	private void validate(String number) throws BadNumberException{
		try{
			if (!checkNum(number))
				throw new BadNumberException();
		} catch (Exception e){
			throw new BadNumberException();
		}
	}
	
	/*
		Returns a Number which represents "this + n".
	*/
	public Number add(Number n){
		//if the number passed in is negative
		Number out= new Number();
		if (Character.compare(n.toString().charAt(0),'-') == 0  && negative){
			out= addAbsolute(n);
			out.reverseSign();
		}else if (Character.compare(n.toString().charAt(0),'-') == 0  && !negative){
			out= subtract(n);
		}else {
			out= addAbsolute(n);
		}
		//System.out.println(out.toString());
		return out;
	}
	/*
		 Returns a Number which represents "this - n"
	*/
	public Number subtract(Number n){
		//if the number passed in is negative
		Number out= new Number();
		//a-(-b)= a+b
		if (Character.compare(n.toString().charAt(0),'-') == 0  && !negative){
			out= addAbsolute(n);
		//-a- b= -(a+b)
		}else if (Character.compare(n.toString().charAt(0),'-') != 0  && negative){
			out= addAbsolute(n);
			out.reverseSign();
		//-a-(-b)= -a+b= -(a-b)=> >0 a>b, <0 a<b 
		} else if (negative && Character.compare(n.toString().charAt(0),'-') == 0 ){
			out=subtractAbsolute(n);
			if (compareToAbsolute(n)>0)
				out.reverseSign();
		}
		//a-b=> <0 a>b; >0 a<b 
		//a-b=-(b-a)
		else{
			//if a > b
			if (compareToAbsolute(n)>0){
				out= subtractAbsolute(n);
			}else{
				out=n.subtract(new Number(toString()));
				out.reverseSign();
			}
		}
		//System.out.println(out.toString());
		return out;
	}
	/*
		Returns a Number which represents "this * n"
	*/
	public Number multiply(Number n){
		Number out= new Number();
		out= multiplyabs(n);
		//-a * -b = ab 
		if (negative ^ Character.compare(n.toString().charAt(0),'-')==0)
			out.reverseSign();
		return out;
	}
	/*
		Reverses the value of negative
	*/
	public void reverseSign(){
		//high.data= high.data * (-1);
		negative=!negative;
	}
	/*
		Returns a String representation of the Number (so it can be displayed by System.out.print())
	*/
	public String toString(){
		StringBuilder out= new StringBuilder();
		try {
		Node temp = new Node();
		temp= high;
		if (negative)
			out.append("-");
		int dotPlace= 0;
		while(temp.next != null){
			if (dotPlace== (digitCount-decimalPlaces)){
				out.append(".");;
				dotPlace++;
			}else {
				out.append(temp.data);;
				dotPlace++;
				temp= temp.next;
			}
		}
		out.append(low.data);
		} catch(Exception e){
			return null;
		}
		return out.toString();
	}
	private Number addAbsolute(Number n){
		String num;
		//make the numbers absolute
		if (Character.compare(n.toString().charAt(0),'-')==0){
			n.reverseSign();
			num=n.toString();
		}else
			num=n.toString();
		if (negative)
			reverseSign();
		//finding the decimal place in n 
		int decimal=0;
		for (int i=0; i< num.length(); i++){
			if (Character.compare(num.charAt(i),'.')==0){
				decimal= num.length()-(i+1);
				//System.out.println(i);
				break;
			}
		}
		//removing the . in n
		num = num.replace(".","");
		//declaring
		int carry=0;
		int ctr=0;
		int decimalplace=0;
		Node temp= low;
		int index= num.length()-1;
		StringBuilder out= new StringBuilder();
		/**
			lining up decimal places
			lining up by moving the numbers afte the decimal.
			if both number decimal == -> lined up
		*/
		//dif == number places - n number places
		int dif = decimalPlaces- decimal;
		
		//checking and lining up
		while (true){
			//numbers already lined up
			if (dif ==0){
				if((decimalPlaces- decimal)>0)
					decimalplace=decimalPlaces;
				else if ((decimalPlaces- decimal)<0)
					decimalplace=decimal;
				else
					decimalplace=decimalPlaces;
				break;
			}
			//number decimalPlaces is bigger than n
			else if (dif >0){
				out.append(temp.data);
				temp=temp.previous;
				dif--;
				decimalplace=decimalPlaces;
			}
			//if n number places if bigger than nujmber
			else{
				out.append(num.charAt(index));
				index--;
				dif++;
				decimalplace=decimal;
			}
		}
		//System.out.println(decimalplace);
		
		//adding
		int a;
		while(temp!= null){
			if (index<0)
				a=temp.data+carry;
			else
				a=temp.data+Character.digit(num.charAt(index),10)+carry;
			out.append(a%10);
			carry= a/10;
			temp=temp.previous;
			index--;
		}
		while (index>=0){
			a=Character.digit(num.charAt(index),10)+carry;
			out.append(a%10);
			carry= a/10;
			index--;
		}
		if (carry != 0){
			out.append(1);
		}
		
		//reverse the string and add . to it
		out.reverse();
		//System.out.println(decimalplace);
		out.insert(out.length()-decimalplace,".");
	//	System.out.println(out.toString());
		return new Number(out.toString());
	}
	private Number subtractAbsolute(Number n){
		String num;
		//make the numbers absolute
		if (Character.compare(n.toString().charAt(0),'-')==0){
			n.reverseSign();
			num=n.toString();
		}else
			num=n.toString();
		if (negative)
			reverseSign();
		//finding the decimal place in n 
		int decimal=0;
		for (int i=0; i< num.length(); i++){
			if (Character.compare(num.charAt(i),'.')==0){
				decimal= num.length()-(i+1);
				//System.out.println(i);
				break;
			}
		}
		//removing the . in n
		num = num.replace(".","");
	
		//declaring
		int borrow=0;
		int ctr=0;
		int decimalplace=0;
		Node temp= low;
		int index= num.length()-1;
		StringBuilder out= new StringBuilder();
		/**
			lining up decimal places
			lining up by moving the numbers afte the decimal.
			if both number decimal == -> lined up
		*/
		//dif == number places - n number places
		int dif = decimalPlaces- decimal;
		
		int a;
		//checking and lining up
		while (true){
			//numbers already lined up
			if (dif ==0){
				if((decimalPlaces- decimal)>0)
					decimalplace=decimalPlaces;
				else if ((decimalPlaces- decimal)<0)
					decimalplace=decimal;
				else
					decimalplace=decimalPlaces;
				break;
			}
			//number decimalPlaces is bigger than n
			//n-0
			else if (dif >0){
				out.append(temp.data);
				temp=temp.previous;
				dif--;
				decimalplace=decimalPlaces;
			}
			//if n number places if bigger than number
			//means 0-n
			else{
				out.append(num.charAt(index));
				index--;
				dif++;
				decimalplace=decimal;
			}
		}

		//subtracting
		while(temp!= null){
			if (index<0)
				a=temp.data-borrow;
			else
				a=temp.data-Character.digit(num.charAt(index),10)-borrow;
			if (a <0){
				a+=10;
				borrow=1;
			}else 
				borrow=0;
			out.append(a);
			temp=temp.previous;
			index--;
		}
		
		while (index>=0){
			a=0-Character.digit(num.charAt(index),10)-borrow;
			if (a <0){
				a+=10;
				borrow=1;
			}else 
				borrow=0;
			out.append(a);
			index--;
		}
		
		//adding the '.'
		out.reverse();
		out.insert(out.length()-decimalplace,".");
		//System.out.println(out.toString());
		return new Number(out.toString());
	}
	
	private Number multiplyabs(Number n){
		String num;
		//make the numbers absolute
		if (Character.compare(n.toString().charAt(0),'-')==0){
			n.reverseSign();
			num=n.toString();
		}else
			num=n.toString();
		if (negative)
			reverseSign();
		//finding the decimal place in n 
		int decimal=0;
		for (int i=0; i< num.length(); i++){
			if (Character.compare(num.charAt(i),'.')==0){
				decimal= num.length()-(i+1);
				//System.out.println(i);
				break;
			}
		}
		//removing the . in n
		num = num.replace(".","");
		
		//declaring
		int decimalplace= decimalPlaces +decimal;
		StringBuilder partialProduct = new StringBuilder();
		Node temp = low;
		int carry=0;
		int a=0;
		StringBuilder product = new StringBuilder();
		Number result= new Number();
		
		//doing the do
		for(int index=0; index < num.length(); index++){
			while(temp!=null){
				a= temp.data * Character.digit(num.charAt(index),10) + carry;
				carry = a/10;
				a= a%10;
				partialProduct.append(a);
				temp=temp.previous;
			}
			if (carry != 0){
				partialProduct.append(carry);
			}
			partialProduct.reverse();
			product.append("0");
			result= new Number(product.toString());
			result=result.add(new Number(partialProduct.toString()));
			product= new StringBuilder(result.toString());
			partialProduct=new StringBuilder();
			temp=low;
		}
		if (decimalplace!=0)
			product.insert(product.length()-decimalplace-1,".");
		//System.out.println("out "+product.toString());
		return new Number(product.toString());
	}
	
	/**
		return >0 if bigger
		return <0 if small
		retrun ==0 if equal
	*/
	private int compareToAbsolute(Number n){
		String num= n.toString();
		//remove any '-' signs
		num=num.replace("-","");
		//finding the decimal place in n 
		int decimal=0;
		for (int i=0; i< num.length(); i++){
			if (Character.compare(num.charAt(i),'.')==0){
				decimal= num.length()-(i+1);
				break;
			}
		}
		if ((digitCount-decimalPlaces)> (num.length()-decimal-1))
			return 1;
		else if ((digitCount-decimalPlaces)< (num.length()-decimal-1))
			return -1;
		else{
			int numIndex=0;
			Node temp= new Node();
			temp=high;
			while(temp.next!= null){
				if (Character.digit(num.charAt(numIndex),10)> temp.data)
					return -1;
				else if (Character.digit(num.charAt(numIndex),10)< temp.data)
					return 1;
				else{
					if (numIndex < num.length())
						numIndex++;
					else 
						break;
				}
				temp=temp.next;
			}
			if (numIndex<num.length()){
				//what if there is decimalPlaces is bigger than another's?
				return -1;
			}else if (temp.next!= null){
				return 1;
			}
		}
		return 0;
	}
	/**
		inner class for Node
	*/
	static class Node{
		int data;
		Node next;
		Node previous;
		
		public Node (){
			this.previous=null;
			this.next=null;
			this.data=-1;
		}
		
		public Node (int data){
			this.data=data;
		}
	}
}