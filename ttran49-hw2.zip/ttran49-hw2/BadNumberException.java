public class BadNumberException extends Exception{
	public BadNumberException(){
		
	}
	public BadNumberException(String str){
		super(str);
	}
}