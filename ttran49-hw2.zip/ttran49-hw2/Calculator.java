import java.util.*;
import java.io.*;

public class Calculator extends Number{
	private void prompt(){
		System.out.println("enter a value: e		add: a");
		System.out.println("substract: s			multiply: m");
		System.out.println("resesve sign: r			clear: c");
		System.out.println("quit: q");
	}
	private boolean check(String option){
		//GENIUS!!!
		if ("e".equals(option))
			return true;
		else if ("a".equals(option))
			return true;
		else if ("s".equals(option))
			return true;
		else if ("m".equals(option))
			return true;
		else if ("r".equals(option))
			return true;
		else if ("c".equals(option))
			return true;
		else if ("q".equals(option))
			return true;
		return false;
	}
	private Number num= new Number();
	private void start(){
		prompt();
		Scanner in  = new Scanner(System.in);
		String option= in.nextLine();
		while (!check((option))){
			System.out.println("INVALID INPUT PLEASE ENTER AGAIN");
			prompt();
			option= in.nextLine();
		}
		//entering a value
		while ("e".equals(option)){
			System.out.print("value: ");
			String number = in.nextLine();
			//System.out.println(number);
			Number temp= new Number(number);
			num=temp;
			System.out.println("Created value: "+num.toString());
			start();
			return;
		}
		
		//add
		while ("a".equals(option)){
			System.out.print("value: ");
			String number = in.nextLine();
			Number temp = new Number(number);
			num=num.add(temp);
			System.out.println("Result: "+num.toString());
			start();
			return;
		}
		
		//substract
		while ("s".equals(option)){
			System.out.print("value: ");
			String number = in.nextLine();
			Number temp = new Number(number);
			num=num.subtract(temp);
			System.out.println("Result: "+num.toString());
			start();
			return;
		}
		
		//multiplication
		while ("m".equals(option)){
			System.out.print("value: ");
			String number = in.nextLine();
			Number temp = new Number(number);
			num=num.multiply(temp);
			System.out.println("Result: "+num.toString());//num.toString();
			start();
			return;
		}
		
		//resesve sign
		while ("r".equals(option)){
			//System.out.println("da");
			num.reverseSign();
			//System.out.println(num.toString());
			System.out.println("Result: "+num.toString());
			start();
			return;
		}
		
		//clearing
		while ("c".equals(option)){
			num=new Number();
			System.out.println("Result: "+num.toString());
			start();
			return;
		}
		
		if("q".equals(option))
			return;
		return;
	}
	public static void main(String[] args){
		Calculator a = new Calculator();
		a.start();
	}
}