import java.util.*;
public class MyHashMultiMap<KeyType, ValueType> {
 
  // Hash table to hold key/value pairs 
  protected MyHashTable<Entry<KeyType,ValueType>> items;  
 
  // Constructor
  public MyHashMultiMap(){
	  items=new MyHashTable();
  }
 
  // Associates the specified key with the specified value in this map.
  // If key is already associated with a List of values, then value
  // is added to this list; otherwise, a new List is created, value is 
  // added to this List, and key is associated with this new List.
  // Throws IllegalArgumentException if key or value is null.
  public void put(KeyType key, ValueType value){
	  if(key==null||value ==null)
		  throw new IllegalArgumentException();
	  Set<Entry<KeyType,ValueType>> set= items.toSet();
	  //if the set is empty
	  if(set.isEmpty()){
		  LinkedList<ValueType> valuelist= new LinkedList<>();
		  valuelist.add(value);
		  Entry<KeyType,ValueType> temp= new Entry<KeyType,ValueType>(key, valuelist);
		  items.insert(temp);
		  return;
	  }
	  // set not empty
	  Iterator<Entry<KeyType,ValueType>> iter = set.iterator();
	  Entry<KeyType,ValueType> a;
	  LinkedList<ValueType> list= new LinkedList<>();
	  Entry<KeyType,ValueType> t= new Entry<KeyType,ValueType>(key,list);
	  while(iter.hasNext()){
		  if((a=iter.next()).equals(t)){
			  a.valueList.add(value);
			  return;
		  }
		  else{
			  LinkedList<ValueType> valuelist1= new LinkedList<>();
			  valuelist1.add(value);
			  Entry<KeyType,ValueType> temp=new Entry<KeyType,ValueType>(key, valuelist1);
			  items.insert(temp);
			  return;
		  }
	  }
  }
 
  // Returns the List of values that key is associated with, or null if 
  // there is no mapping for key.
  // Throws IllegalArgumentException if key is null.
  public List<ValueType> get(KeyType key){
	  if(key==null)
		  throw new IllegalArgumentException();
	  Set<Entry<KeyType,ValueType>> temp= items.toSet();
	  Iterator<Entry<KeyType,ValueType>> iter = temp.iterator();
	  Entry<KeyType,ValueType> a;
	  LinkedList<ValueType> list= new LinkedList<>();
	  Entry<KeyType,ValueType> t= new Entry<KeyType,ValueType>(key,list);
	  while(iter.hasNext()){
		  if ((a=iter.next()).equals(t))
			  return a.valueList;
	  }
	  return null;
  }
 
  // Returns the number of elements
  // Target Complexity: O(1)
  public int size(){
	  return items.size();
  }
 
  // Returns true if there are no elements.
  // Target Complexity: O(1)
  public boolean isEmpty(){
	  return items.isEmpty();
  }
 
  // Make the map logically empty.
  // Target Complexity: O(1)
  public void clear(){
	  items.clear();
  }
 
  // Returns a Set of the Entries contained in this map.
  public Set<Entry<KeyType, ValueType>> entrySet(){
	  return items.toSet();
  }
  
  // Returns the MyHashTable<T> of items
  protected MyHashTable<Entry<KeyType,ValueType>> getItems(){
	  return items;
  }
 
  // A helper method that returns an Entry created from the 
  // specified key and List. Called by put and get.
  protected MyHashMultiMap.Entry<KeyType,ValueType> 
  makeEntry( KeyType key, LinkedList<ValueType> valueList ) {
     return new MyHashMultiMap.Entry<KeyType, ValueType>(key,valueList);
  }
 
  // A helper method for creating an Entry from a key value.
  // Called by put and get.
  protected MyHashMultiMap.Entry<KeyType,ValueType> 
  makeEntry( KeyType key ) {
     return makeEntry(key, null );
  }
 
  public static class Entry<KeyType, ValueType> {
	  protected KeyType key;
	  protected LinkedList<ValueType> valueList;
	 
	  // Constructor
	  // Target Complexity: O(1)               
	  public Entry( KeyType k, LinkedList<ValueType> list ){
		  this.key=k;
		  this.valueList=list;
	  }
	 
	  // Returns the hash code value for this map entry. 
	  // The hashCode of the Entry is the hashCode of the Entry's key, i.e,
	  // the Entry’s value is ignored during hashing.
	  public int hashCode(){
		  return key.hashCode();
	  }
	 
	  // Compares the specified object with this entry for equality.
	  // The equality of two Entries is based on the equality of their keys.
	  public boolean equals( Object rhs ){
		  if(rhs == null)
			  return false;
		  Entry<KeyType, ValueType> casted = (Entry<KeyType, ValueType>) rhs;
		  if(casted.getKey()==null && key==null)
			  return true;
		  if(key==null)
			  return false;
		  return casted.getKey().equals(key);
	  }
	 
	  // Returns the key corresponding to this entry.          
	  public KeyType getKey(){
		  return key;
	  }
	 
	  // Returns the value corresponding to this entry.
	  public LinkedList<ValueType> getValue(){
		  return valueList;
	  }
	  //return the string
	  public String toString(){
			String out;
			out= key+", "+valueList.toString();
			return out;
		}
	}
}