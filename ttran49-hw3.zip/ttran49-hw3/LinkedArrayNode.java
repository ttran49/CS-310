import java.util.*;
public class LinkedArrayNode<T> {
  protected LinkedArrayNode<T> prev;
  protected LinkedArrayNode<T> next;
  protected Object[] array;          // array holds T objects
  protected static final int DEFAULTLENGTHOFARRAY = 16;
  protected int arraySize;    // number of elements in the array.
 
 
  // Workhorse constructor. Initialize prev and next and the size of the
  // array, and create an array of Objects of the specified length.
  // Parameter lengthOfArray is used to create array. The value of 
  // lengthOfArray need not be saved since it is essentially array.length.
  // Throws IllegalArgumentException if lengthOfArray < 0.
  public LinkedArrayNode(LinkedArrayNode<T> prev,LinkedArrayNode<T> next, int lengthOfArray){
	this.prev=prev;
	this.next=next;
	array= new Object[lengthOfArray];
  }
 
  // Convenience constructor. Calls the workhorse constructor with 
  // DEFAULTLENGTHOFARRAY as the argument.
  public LinkedArrayNode(LinkedArrayNode<T> prev,LinkedArrayNode<T> next){
	  this.prev=prev;
	  this.next=next;
	  array= new Object[DEFAULTLENGTHOFARRAY];
  }
 
  // Add element x to the end of the array.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(1)
  public void add(T x){
	if (x == null)
		throw new IllegalArgumentException();
	int i=0;
	//empty array
	if(array[0]==null){
		array[i]=x;
	}
	else {
		i=0;
		while(i < array.length){
			if(array[i]==null)
				break;
			i++;
		}
		//System.out.println("array node i and length  "+i + " "+ array.length );
		array[i]=x;
	}
	arraySize++;
	//System.out.println("a: "+arraySize); 
	}
  
 
  // Locate and remove the first element that equals x. This may require 
  // elements to be shifted (left). Returns a reference to the removed 
  // element, or null if the element was not removed.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(n)
  public T remove(T x){
	//System.out.println(Arrays.toString(array)); 
	//System.out.println(arraySize);
	if(x==null)
		throw new IllegalArgumentException();
	boolean removed=false;
	int i;
	for (i =0; i < array.length; i++){
		if (array[i].equals((Object)x)){
			//System.out.println("ASdasdada");
			array[i]=null;
			removed=true;
			break;
		}
	}
	if (removed){
		Object temp=new Object();
		/* shifting */
		for(int j=i+1; j < array.length; j++){
			temp=array[j];
			array[j-1]=temp;
		}
		array[array.length-1]=null;
		arraySize--;
	//	System.out.println(Arrays.toString(array)); 
		return x;	
	}
	return null;
  }
 
  // Returns a reference to the first element in the array that equals x, or 
  // null if there is no matching element. 
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(N)
  public T getMatch(T x){
	if(x==null)
		throw new IllegalArgumentException();
	boolean found=false;
	int i;
	for (i =0; i < array.length; i++){
		if (x.equals((T)array[i])){
			found=true;
			break;
		}
	}
	if(found){
		return (T) array[i];
	}
	return null;
  }
 
  // toString() - create a pretty representation of the node by
  // showing all of the elements in the array.
  // Target Complexity: O(n)
  // Example: an array with size four and length five: 1, 2, 4, 6
  public String toString(){
	  StringBuilder out = new StringBuilder();
	  if(arraySize==0)
			return out.toString();
	  for(int i=0; i < arraySize; i++){
		  out.append(array[i]);
		  if(i != arraySize-1)
			  out.append(", ");
	  }
	  return out.toString();
  }
}