import java.util.*;
public class MyHashTable<T> {
  protected static final int DEFAULTTABLESIZE = 101; 
  protected int size;
  protected int tableSize;
  protected LinkedArrays[] table;
 
  // Workhorse constructor. The internal table size is tableSize if
  // tableSize is prime or the next prime number that is
  // greater than tableSize if tableSize is not prime.
  public MyHashTable( int tableSize ){
	  this.tableSize=tableSize;
	  table = new LinkedArrays[tableSize];
	  size=0;
  }
 
  // Convenience constructor. DEFAULTTABLESIZE is 101
  public MyHashTable( ){
	  this.tableSize=DEFAULTTABLESIZE;
	  table = new LinkedArrays[DEFAULTTABLESIZE];
	  size=0;
  }
  
  // Make the hash table logically empty.
  // Target Complexity: O(1)
  public void clear(){
	  size=0;
	  table = new LinkedArrays[tableSize];
  }
 
  // Insert x into the hash table. If x is already present, then do 
  // nothing.
  // Throws IllegalArgumentException if x is null.
  public void insert(T x){
	  if(x==null)
		  throw new IllegalArgumentException();
	  if(!contains(x)){
		  if(table[myhash(x)]==null){
			LinkedArrays temp= new LinkedArrays(tableSize);
			temp.add(x);
			table[myhash(x)]=temp;
			size++;
		  }else {
			  table[myhash(x)].add(x);
			  size++;
		  }
		  if(size > tableSize/2) 
			  rehash();
	  }
  }
 
  // Remove x from the hash table.
  // Throws IllegalArgumentException if x is null.
  public void remove( T x ){
	  if(x==null)
		  throw new IllegalArgumentException();
	  if(contains(x)){
		  for (int i=0; i < tableSize; i++){
			  if(table[i]!= null){
				  if(table[i].contains(x)){
					 table[i].remove(x);
					 break;
				  }
				}
			}
		  size--;
		}
	}
 
  // Return true if x is in the hash table
  // Throws IllegalArgumentException if x is null.
  public boolean contains(T x ){
	  if(x==null)
		  throw new IllegalArgumentException();
	  boolean out=false;
	  for (int i=0; i < tableSize; i++){
		  if(table[i]!= null){
			  if((out=table[i].contains(x)))
				 break;
		  }
	  }
	  return out;
  }
 
  // Return the first element in the hashed-to LinkedArrays that equals 
  // x, or null if there is no such element.
  // Throws IllegalArgumentException if x is null.
  public T getMatch(T x){
	  if(x==null)
		  throw new IllegalArgumentException();
	  T out =null;
	  for (int i=0; i < tableSize; i++){
		  if(table[i]!= null){
			  if((out= (T) table[i].getMatch(x)) != null)
				 break;
		  }
	  }
	  return out;
  }
 
  // Returns the number of elements
  // Target Complexity: O(1)
  public int size(){
	  return size;
  }
 
  // Returns true if there are no elements.
  // Target Complexity: O(1)
  public boolean isEmpty(){
	  return size()==0;
  }
 
  // Returns a Set containing all of the T elements in the table. (Set is
  // an interface implemented by classes HashSet and TreeSet.)
  public Set<T> toSet(){
	  HashSet<T> out = new HashSet<T>();
	  Object[] temp;
	  for (int i=0; i < tableSize; i++){
		  if(table[i]!= null){
			  LinkedArrayNode ctr= table[i].head;
			  while(ctr.next!= null){
				  ctr=ctr.next;
				  temp= ctr.array;
				  for(int j=0; i < temp.length; j++){
					  if(j==temp.length)
						  break;
					  if(temp[j]!= null){
						  //System.out.println(temp[j]);
						  T shit= (T) temp[j];
						   out.add(shit);
					  }
				  }
				}
		  }
	  }
	  return out;
  }
 
  // Returns a pretty representation of the hash table.
  // Uses toString() of LinkedArrays.
  // Example: For a table of size 3
  // Table:
  // 0: | two |
  // 1: | one, four |
  // 2: 
  public String toString(){
	 StringBuilder out= new StringBuilder();
	 out.append("Table:\n");
	 for(int i =0; i< table.length; i++){
			out.append(i+": ");
			if(table[i]!= null)
				out.append(table[i].toString()+"\n");
			out.append("\n");
	 }
	 
	 return out.toString();
  }
 
  // Increases the size of the table by finding a prime number 
  // (nextPrime) at least as large as twice the current table size. 
  // Rehashes the elements of the hash table when size is greater than 
  // tableSize/2.
  protected void rehash(){
	  int temp;
	  //getting new size
	  temp= nextPrime(tableSize*2);
	  //new arr[]
	  LinkedArrays[] arr= new LinkedArrays[temp];
	  //copying stuff over
	  Set<T> temp1 = toSet();
	  Iterator<T> iter = temp1.iterator();
	  T a;
	  tableSize=temp;
	  while(iter.hasNext()){
		  a=iter.next();
		  temp=myhash(a);
		  if(arr[temp]==null){
			  LinkedArrays<T> node = new LinkedArrays<>();
			  node.add(a);
			  arr[temp]= node;
		  } else{
			  arr[temp].add(a);
		  }
	  }
	  //assigning new array to the existing table
	  table= arr;
  }
 
  // Internal method for computing the hash value from the hashCode of x.
  protected int myhash(T x) {
    int hashVal = x.hashCode( );
    hashVal %= tableSize;
    if( hashVal < 0 )
      hashVal += tableSize;
    return hashVal;
  }
 
  // Internal method to find a prime number at least as large as n. 
  protected static int nextPrime(int n ){
    if( n % 2 == 0 )
      n++;
    for( ; !isPrime( n ); n += 2 )
      ;
    return n;
  }
 
  // Internal method to test if a number is prime. Not an efficient 
  // algorithm. 
  protected static boolean isPrime(int n ) {
    if( n == 2 || n == 3 )
      return true;
    if( n == 1 || n % 2 == 0 )
      return false;
    for( int i = 3; i * i <= n; i += 2 )
      if( n % i == 0 )
        return false;
    return true;
  }
}