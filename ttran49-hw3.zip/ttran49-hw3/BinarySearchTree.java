import java.util.*;
public class BinarySearchTree<T extends Comparable<? super T>> {
 protected TreeNode<T> root;        // root of tree
 protected int size;                // size of tree
 protected enum PrePostIn {PREORDER, POSTORDER, INORDER};

 
 // Constructor
 // Initialize variables – root is null and size is 0.
 public BinarySearchTree(){
	 root=null;
	 size=0;
 }
 
 // Constructor that builds a tree from the values in sorted List L.
 // Initialize variables – root is null and size is 0 - and call 
 // recursive method buildTree() if L.size() > 0.
 // Throws IllegalArgumentException if L is null or any element in L is 
 // null.
 public BinarySearchTree(List<T> L){
	 if (L== null)
		 throw new IllegalArgumentException();
	 if(L.size()>0){
		 root=buildTree(0,L.size()-1, L);
		 size= L.size();
	 }
	 else{
		 root=null;
		 size=0;
	 }
 }
    
 // Builds a balanced tree from the values in sorted List L.
 // Start and end are the start and end positions of a sub-list of L.
 // Returns the root of the subtree containing the elements in the 
 // sub-list of L.
 // Throws IllegalArgumentException if L or any element in L is null.
 // Called by BinarySearchTree(List<T> L) and balance().
 // This is a recursive method.
 // Target Complexity: O(1)
 protected TreeNode<T> buildTree(int start, int end, List<T> L){
	 if(L == null)
		 throw new IllegalArgumentException();
	 if(L.size()==1)
		 return new TreeNode<T>(L.get(0),null,null,null);
	 int mid=middle(start,end);
	 TreeNode<T> midNode = new TreeNode<T>(L.get(mid),null,null,null);
	 //if there is only 2 in list
	 // midNode is going to get index 1
	 if(L.size()==2){
		 //node with smaller value 
		 TreeNode<T> smallNode= new TreeNode<T>(L.get(0),null,null,null);
		 smallNode.right=midNode;
		 return smallNode;
	 }
	 else{
		 if(mid >0){
			 //building the left tree
			 //checking if sub-list is empty, if empty dont run
			 List<T> left= L.subList(0,mid);
			 //System.out.println("left "+Arrays.toString(left.toArray()));
			 if(left.size()>0)
				midNode.left= buildTree(0,left.size(),left);		 
			
			//building the right tree
			//checking if sub-list is empty, if empty dont run
			 List<T> right= L.subList(mid+1,L.size());
			 //System.out.println("right "+Arrays.toString(right.toArray()));
			 if (right.size()>0)
				midNode.right=buildTree(0,right.size(),right);
		 }
	 }
	 return midNode;
 }
 
 // If x is not already in the tree, inserts x and returns true.
 // If x is already in the tree, does not insert x and returns false.
 // Sets the new nodes left, right, and parent references. 
 // On the first call to this method, start and end are the positions at 
 // the beginning and end of List L.
 // Throws IllegalArgumentException if x is null.
 // This is a non-recursive method.
 public boolean insert(T x){
	 if(x==null)
		 throw new IllegalArgumentException();
	 if (root ==null){
		 root= new TreeNode(x,null,null,null);
		 size++;
		 return true;
	 }
	 return insert(x,root);
 }
 
 //insert value p 
 private boolean insert(T x, TreeNode<T> root){
	 int compare= x.compareTo(root.data);
	 if (compare== 0){
		 //duplicate
		 return false;
	 }
	 //go to left
	 if (compare<0){
		 if (root.left == null){
			 root.left= new TreeNode<T>(x,null,null,root);
			 size++;
			 return true;
		 } else
			return insert(x, root.left);
	 }
	 if(root.right==null){
		 root.right=new TreeNode<T>(x,null,null,root);
		 size++;
		 return true;
	 }
	 return insert(x, root.right);
 }
 
 // Removes x from the tree.
 // Return true if x is removed; otherwise, return false;
// Throws IllegalArgumentException if x is null.
 // This is a non-recursive method.
 public boolean remove( T x){
	 if (x== null)
		 throw new IllegalArgumentException();
	 return remove (x, root);
 }
 
 private boolean remove (T x, TreeNode<T> root){
	 //not found
	 if(root==null)
		 return false;
	 int compare = x.compareTo(root.data);
	 //found
	 if(compare==0){
		 //this is a leaf
		 if(root.left==null && root.right==null){
			 if(root.parent.left.equals(root))
				 root.parent.left=null;
			 else
				 root.parent.right=null;
			 root.parent=null;
			 size--;
			 return true;
		 }
		 //has 1 children
		 else if (root.left==null ^ root.right==null){
			 if(this.root.equals(root)){
				 if(root.right != null)
					 this.root= root.right;
				 else
					 this.root=root.left;
				 size--;
				 return true;
			 } else {
				 int comp= x.compareTo( (T) root.parent.data);
				 if(comp<0){
					 //child is left
					 if(root.left !=null){
						 root.left.parent=root.parent;
						 root.parent.left=root.left;
						 size--;
						 return true;
					 }
					root.right.parent=root.parent;
					root.parent.left=root.right;
					size--;
					return true;
				 }else if (comp>0){
					 //child is right
					 if(root.left !=null){
						 root.left.parent=root.parent;
						 root.parent.right=root.left;
						 size--;
						 return true;
					 }
					root.right.parent=root.parent;
					root.parent.right=root.right;
					size--;
					return true;
				 }
			 }
		 }
		 //has 2 children
		 else {
			 //find the smallest node on the right sub tree
			 TreeNode<T> temp= root.right;
			 while (temp.left != null)
				 temp=temp.left;
			 root.data= temp.data;
			 if(temp.parent==root)
				 root.right=null;
			 else
				temp.parent.left=null;
			 size--;
			 return true;
		 }
	 }
	 if(compare <0)
		 return remove(x, root.left);
	 return remove(x,root.right);
 }
 
 // Returns an element in the list that equals x, or null if there is no 
 // such element.
 // Throws IllegalArgumentException if x is null.
 // May call method search.
 // This is a non-recursive method.
 public T getMatch(T x){
	 if (x== null)
		 throw new IllegalArgumentException();
	 return match(x, root);
 }
 //matching 
 private T match (T x, TreeNode<T> root){
	 if(root==null)
		 return null;
	 int compare= x.compareTo(root.data);
	 if(compare==0)
		 return (T) root.data;
	 if(compare<0)
		 return (T) match(x, root.left);
	 return (T) match(x,root.right);
 }
 
 // Returns true if there is an element in the list that equals x.
 // Throws IllegalArgumentException if x is null.
 // May call method search.
 // This is a non-recursive method.
 public boolean contains(T x){
	 if (x== null)
		 throw new IllegalArgumentException();
	 if(getMatch(x)==null)
		 return false;
	 return true;
 }
 
 // Return a reference to the node that contains an element that equals 
 // x or null if there is no such node.
 // Any method that calls this method should ensure that x is not null.
 // This is a non-recursive method.
 protected TreeNode<T> search(T x){
	 if (x== null)
		 throw new IllegalArgumentException();
	 if(contains(x)){
		 return search(x, root);
	 }
	 return null;
 }
 
 //private search
 private TreeNode<T> search(T x, TreeNode<T> root){
	 if(root == null)
		 return null;
	 int compare= x.compareTo(root.data);
	 if(compare ==0)
		 return root;
	 if(compare <0)
		 return search(x, root.left);
	 return search(x, root.right);
 }
 
 // Returns a reference to the node that contains the minimum element in 
 // the subtree rooted at node n.
 // Called by method next(); method next() should ensure that node n is 
 // not null.
 // This is a non-recursive method.
 protected TreeNode<T> getMinNode(TreeNode<T> n){
	 TreeNode<T> temp=root;
	 while(temp.left != null){
		 temp=temp.left;
	 }
	 return temp;
 }
 
 // Returns a reference to the node that contains the minimum element in 
 // the subtree rooted at node n; the found node is also removed from the 
 // tree. Note the n may be the node containing the minimum element. 
 // Any method that calls this method should ensure that n is not null
 //   and that n is not the root.
 // This is a non-recursive method.
 protected TreeNode<T> getAndRemoveMinNode(TreeNode<T> n){
	 if(root.equals(n) || n==null)
		 return null;
	 TreeNode<T> temp= getMinNode(root);
	 remove(temp.data);
	 return temp;
 }
   
 // Returns the node that is the node after node n in sorted order,
 // as determined by an inorder traversal of the tree. The next node is 
 // node with the smallest data element greater than n.data.
 // May be called by remove().
 // This is a non-recursive method.
 protected TreeNode<T> next(TreeNode<T> n){
	 if(n==null)
		 return null;
	 List<T> temp=getSortedListOfElements();
	 int index = temp.indexOf(n.data);
	 if(index == temp.size()-1)
		 return null;
	 return search(temp.get(index+1));
 }
 
 // Returns the node that is the node before n in sorted order, as
 // determined by an inorder traversal of the tree. The previous node is 
 // node with the largest data element smaller than n.data.
 // Methods next() and previous() are symmetric.
 // This is a non-recursive method.
 protected TreeNode<T> previous(TreeNode<T> n){
	 if(n==null)
		 return null;
	 List<T> temp=getSortedListOfElements();
	 int index = temp.indexOf(n.data);
	 if(index == 0)
		 return null;
	 else 
		 return search(temp.get(index-1));
 }
 
 // Returns the number of elements in the tree
 // Target Complexity: O(1)
 public int size(){
	 return size;
 }
 
 // Returns true if there are no elements.
 // Target Complexity: O(1)
 public boolean isEmpty(){
	 return size()==0;
 }
 
 // Make the tree logically empty.
 // Target Complexity: O(1)
 public void clear(){
	 size=0;
	 root=null;
 }
 
 private ArrayList<T> traverse = new ArrayList<>();
 
 // Convenience method that returns a List of elements in sorted order.  
 // Calls getListOfElements(PrePostIn.INORDER);
 public List<T> getSortedListOfElements(){
	 return getListOfElements(PrePostIn.INORDER);
 }
 
 // Returns a List of elements in the order specified by parameter order, 
 // which is either PREORDER, POSTORDER, or INORDER.
 // Calls fillListOfElements(root,order)
 public List<T> getListOfElements(PrePostIn order){
	 return fillListOfElements(root,order);
 }
 
 // Returns a List of elements in the order specified by parameter order, 
 // which is either PREORDER, POSTORDER, or INORDER.
 // This is a non-recursive method.
 // Target Complexity: O(1)
 protected List<T> fillListOfElements(TreeNode<T> node, PrePostIn order){
	 traverse.clear();
	 if(order==PrePostIn.INORDER)
		 inorder(root);
	 if(order==PrePostIn.POSTORDER)
		 postorder(root);
	 if(order==PrePostIn.PREORDER)
		 preorder(root);
	 return traverse;
 }
 //inorder traversal
 private void inorder(TreeNode<T> root){
	 if(root != null){
		 inorder(root.left);
		 traverse.add(root.data);
		 inorder(root.right);
	 }
 }
 //postorder traversal
 private void postorder(TreeNode<T> root){
	 if(root != null){
		 postorder(root.left);
		 postorder(root.right);
		 traverse.add(root.data);
	 }
 }
 //preorder traversal
 private void preorder(TreeNode<T> root){
	 if(root != null){
		 traverse.add(root.data);
		 preorder(root.left);
		 preorder(root.right);
	 }
 }
 
 // Balances the tree.
 // Calls buildTree(int start, int end, List<T> L) where L is a sorted 
 // List of the elements in the tree, and start and end are the positions 
 // at the beginning and end of L.
 public void balance(){
	 List<T> temp= fillListOfElements(root,PrePostIn.INORDER);
	 root=buildTree(0,temp.size()-1,temp);
 }
 
 // Helper middle to compute the middle position of a sub-list
 protected int middle(int start, int end) {return (start + end) / 2;}
}