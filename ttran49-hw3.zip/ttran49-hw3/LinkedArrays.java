import java.util.*;
public class LinkedArrays<T> {
  protected int size;                 // number of elements
  protected int nodeCount;            // number of LinkedArrayNodes
  protected final int lengthOfArrays; // value initialized in constructor
  protected static final int DEFAULTLENGTHOFARRAYS = 16;
  protected LinkedArrayNode<T> head;        // dummy nodes head and tail
  protected LinkedArrayNode<T> tail;
 
  // Workhorse constructor that initializes variables.
  // Throws IllegalArgumentException if lengthOfArray < 0.
  LinkedArrays (int lengthOfArrays){
	  if(lengthOfArrays<0)
		throw new IllegalArgumentException();
	  this.lengthOfArrays=lengthOfArrays;
	  head= new LinkedArrayNode(null,null);
	  tail= new LinkedArrayNode(null,null);
	  head.next=tail;
	  tail.prev=head;
  }
 
  // Convenience constructor. Calls the workhorse constructor with 
  // DEFAULTLENGTHOFARRAYS as the argument.
  LinkedArrays(){
	 this.lengthOfArrays=DEFAULTLENGTHOFARRAYS;
	 head= new LinkedArrayNode(null,null);
	 tail= new LinkedArrayNode(null,null);
	 head.next=tail;
	 tail.prev=head;
  }
 
  // Make this LinkedArrays logically empty.
  // Target Complexity: O(1)
  // Implementation note: It is not necessary to remove() all of the 
  // elements; instead, some data members can be reinitialized.
  // Target Complexity: O(1)
  public void clear(){
	size=0;
	nodeCount=0;
	head.next=null;
	tail.prev=null;
  }
 
  // Returns the number of elements
  // Target Complexity: O(1)
  public int size(){
	  return size;
  }
 
  // Returns the number of LinkedArrayNodes.
  // Target Complexity: O(1)
  public int nodeCount(){
	  return nodeCount;
  }
 
  // Returns true if there are no elements in this LinkedArrays
  // Target Complexity: O(1)
  public boolean isEmpty(){
	return size()==0;
  }
 
  // Returns the first element that equals x, or null 
  // if there is no such element.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(n) for n elements
  public T getMatch(T x){
	if(x==null)
		throw new IllegalArgumentException();
	
	LinkedArrayNode temp = head;
	T out=null;
	while(temp.next!= null){
		temp=temp.next;
		out= (T) temp.getMatch(x);
		if(out != null)
			break;
	}
	return out;
  }
 
  // Returns true if this LinkedArrays contains the specified element.
  // Throws IllegalArgumentException if x is null. May call getMatch.
  // Target Complexity: O(n)
  public boolean contains (T x){
	  if (x==null)
		  throw new IllegalArgumentException();
	  LinkedArrayNode temp= head;
	  boolean found =false;
	  while(temp.next!=null){
		  temp=temp.next;
		  if (temp.getMatch(x)!= null){
			  found=true;
			  break;
		  }
	  }
	  return found;
  }
 
  // Insert x into the first LinkedArrayNode with an available space in 
  // its array. 
  // Returns true if x was added.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(number of nodes)
  public boolean add(T x){
	  //empty
	  if (isEmpty()){
		  LinkedArrayNode temp= new LinkedArrayNode(null,null,lengthOfArrays);
		  temp.add(x);
		  temp.prev=head;
		  temp.next=tail;
		  head.next=temp;
		  tail.prev=temp;
		  size=1;
		  nodeCount++;
		  return true;
	  }
	  //if there is still space in a node
	 // System.out.println(size+"   "+lengthOfArrays);
	  if(size < lengthOfArrays){
		  LinkedArrayNode temp=head;
		  while(temp.next != null){
			  temp=temp.next;
			 // System.out.println("a "+temp.array.length);
			 // System.out.println(temp.toString());
			  if(temp.arraySize < temp.array.length){
				  temp.add(x);
				  size++;
				  break;
			  }
		  }
		 // System.out.println(temp.toString());
		  return true;
	  }
	  // no space in any node, create a new one
	  LinkedArrayNode temp= new LinkedArrayNode(null,null,lengthOfArrays);
	  temp.add(x);
	  temp.prev=tail.prev;
	  temp.next=tail;
	  tail.prev.next=temp;
	  tail.prev=temp;
	  size=1;
	  nodeCount++;
	  return true;
  }
 
  // Remove the first occurrence of x if x is present. 
  // Returns a reference to the removed element if it is removed. 
  // When the last data element is removed from (the array in) a
  // LinkedArrayNode, the LinkedArrayNode is removed from the 
  // LinkedArrays.
  // Throws IllegalArgumentException if x is null.
  // Target Complexity: O(n)
  protected T remove(T x){
	  if(x==null)
		  throw new IllegalArgumentException();
	  T out=null;
	  if(contains(x)){
		  LinkedArrayNode temp=head;
		  while(temp.next != null){
			  temp=temp.next;
			  if ((out=(T)temp.remove(x))!=null){
				  if (temp.toString().length()==0){
					  temp.prev.next=temp.next;
					  temp.next.prev=temp.prev;
					  nodeCount--;
				  }
				  size--;
				  break;
			  }
		  }
	  }
	  return out;
  }
    
  // Returns a pretty representation of the LinkedArrays.
  // Example: A LinkedArrays with two LinkedArrayNodes that have arrays 
  // of length two. The size of the first array is two and the size of
  // the second array is one: | 4, 2 | 3 |
  public String toString(){
	  StringBuilder out= new StringBuilder();
	  LinkedArrayNode temp=head;
	  while(temp.next!= tail){
		  temp=temp.next;
		  out.append("| "+temp.toString());
	  }
	  out.append(" |");
	  return out.toString();
  }
}